# tower-blocks-game

In this game, your target is to release the hoisted blocks so as to construct the highest tower.

Github pages: https://harshalparmar.github.io/tower-blocks-game/

![alt text](https://raw.githubusercontent.com/harshalparmar/tower-blocks-game/main/tower-blocks-img.png)
